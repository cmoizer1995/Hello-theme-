<?php get_header(); ?>
<h1>Welcome to Hello World Mento Pro</h1>
<p>This is a clean demo theme for Playground.</p>
<?php get_footer(); ?>
