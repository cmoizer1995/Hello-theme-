<?php
function helloworldmentopro_setup() {
    add_theme_support('title-tag');
    add_theme_support('menus');
}
add_action('after_setup_theme', 'helloworldmentopro_setup');
